-- SQL SCRIPTS TO APPEND DIFFERENT TABLES IN BIG QUERY
-- THE COLUMN STRUCTURE MUST BE THE SAME BEFORE APPENDING THE DIFFERENT TABLES (MARKETS) TOGERHER.

SELECT
  date_created,
  contacts_n,
  contacts_n_1,
  contacts_n_2,
  contacts_n_3,
  contacts_n_4,
  contacts_n_5,
  contacts_n_6,
  contacts_n_7,
  new_type,
  new_market
FROM `pubic-dataset-project.google_fiber_market_1`
UNION ALL
SELECT
  date_created,
  contacts_n,
  contacts_n_1,
  contacts_n_2,
  contacts_n_3,
  contacts_n_4,
  contacts_n_5,
  contacts_n_6,
  contacts_n_7,
  new_type,
  new_market
FROM `pubic-dataset-project.google_fiber_market_2`
UNION ALL
SELECT
  date_created,
  contacts_n,
  contacts_n_1,
  contacts_n_2,
  contacts_n_3,
  contacts_n_4,
  contacts_n_5,
  contacts_n_6,
  contacts_n_7,
  new_type,
  new_market
FROM `pubic-dataset-project.google_fiber_market_3`;